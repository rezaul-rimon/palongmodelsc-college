@extends('frontend.layouts.front_app')

@section('content')

	@include('frontend.layouts.hero_single_page')
    @include('frontend.layouts.class_division')
    @include('frontend.layouts.stipend_students')
	@include('frontend.layouts.students_list')
	
    <div class="mt-5">

    </div>

@endsection
