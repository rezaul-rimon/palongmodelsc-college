<section class="hero-wrap hero-wrap-2" style="background-image: url('frontend/images/bg_single_page.jpg');">
    <div class="overlay"></div>
    <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
        <div class="col-md-9 ftco-animate text-center">
            <h1 class="mb-2 bread">{{ $banner_text }}</h1>
            <p class="breadcrumbs"><span class="mr-2" style="font-size: 18px;"><a href="index.html">প্রথম পাতা <i class="ion-ios-arrow-forward"></i><i class="ion-ios-arrow-forward"></i></a></span><span style="font-size: 18px;">{{ $banner_text }} <i class="ion-ios-arrow-forward"></i><i class="ion-ios-arrow-forward"></i></span></p>
        </div>
    </div>
    </div>
</section>