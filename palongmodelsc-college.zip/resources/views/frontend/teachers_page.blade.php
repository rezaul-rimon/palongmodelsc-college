@extends('frontend.layouts.front_app')

@section('content')

	@include('frontend.layouts.hero_single_page')
    @include('frontend.layouts.teachers')
    <div class="mt-5">

    </div>

@endsection

	

	