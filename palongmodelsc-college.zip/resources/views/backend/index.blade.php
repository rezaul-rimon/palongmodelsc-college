@extends('backend.layouts.back_app')

@section('content')
    @include('backend/layouts/main')
@endsection