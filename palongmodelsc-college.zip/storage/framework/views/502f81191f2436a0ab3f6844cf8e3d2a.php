<?php $__env->startSection('content'); ?>


<style>
    .page-title {
        text-align: left;
        margin: 20px 0 10px 0;
    }

    .add-button {
        text-align: right;
        margin: 20px 0 10px 0;
    }

    @media (max-width: 768px) {
        .page-title {
            text-align: center;
            margin: 20px 0 10px 0;
        }

        .add-button {
            text-align: center;
            margin: 0 0 10px 0;
        }
    }

</style>


<main>
    <div class="container-fluid px-4">
        <div class="row">
            <div class="col-md-6 col-12 page-title">
                <h1 class="text-danger">ইউজার ম্যানেজমেন্ট</h1>
            </div>

            
        </div>

        <div class="col-md-6 offset-md-3">
            <?php if(session()->has('success')): ?>
                <div class="alert alert-success text-center">
                    <?php echo e(session('success')); ?>

                </div>
            <?php elseif(session()->has('error')): ?>
                <div class="alert alert-danger text-center">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>
        </div>
        <script>
            $(document).ready(function() {
                $('.alert').delay(4000).fadeOut(500);
            });
        </script>                

        <table class="table table-responsive table-bordered text-center">
            <colgroup>
                <col style="width: 10%;">
                <col style="width: 15%;">
                <col style="width: 20%;">
                <col style="width: 20%;">
                <col style="width: 10%;">
                <col style="width: 10%;">
                <col style="width: 15%;">
            </colgroup>
            <thead>
                <tr>
                    <th>ক্রম</th>
                    <th>তারিখ ও সময়</th>
                    <th>নাম</th>
                    <th>ইমেইল</th>
                    <th>পারমিশন</th>
                    <th>রোল</th>
                    <th>একশন</th>
                </tr>
            </thead>

            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="align-middle"><?php echo e($loop->iteration); ?></td>
                        <td class="align-middle"><?php echo e($item->created_at); ?></td>
                        <td class="align-middle">
                            <?php echo e($item->name); ?>

                            <?php if($item->id == auth()->user()->id): ?>
                                <span class="text-primary">(You)</span>
                            <?php else: ?>
                            <?php endif; ?>
                        </td>                        
                        <td class="align-middle"><?php echo e($item->email); ?></td>
                        <td class="align-middle">
                            <?php if($item->permission == 1): ?>
                                Yes
                            <?php else: ?>
                                No
                            <?php endif; ?>
                        </td>
                        <td class="align-middle">
                            <?php if($item->role == 1): ?>
                                Admin
                            <?php elseif($item->role == 2): ?>
                                Super Admin
                            <?php else: ?>
                                People
                            <?php endif; ?>
                        </td>                        
                        <td class="align-middle">
                            <a href="<?php echo e(route('backend.edit_user', $item->id)); ?>" class="btn my-1 btn-sm btn-warning">আপডেট</a>
                            <a href="<?php echo e(route('backend.delete_user', $item->id)); ?>" class="btn my-1 btn-sm btn-danger" onclick="return confirm('আপনি কি নিশ্চিত যে আপনি এই শিক্ষককে ডিলিট করতে চান?')">ডিলিট</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td class="text-danger fw-bold" colspan="8">এই পর্যন্ত কোন ইউজার সংযুক্ত করা হয়নি।</td>
                    </tr>
                <?php endif; ?>
            </tbody>   
        </table>
    </div>
</main>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('backend.layouts.back_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\palongmodelsc-college\resources\views/backend/users/users.blade.php ENDPATH**/ ?>