

<?php $__env->startSection('content'); ?>

	<?php echo $__env->make('frontend.layouts.hero_single_page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
	<?php echo $__env->make('frontend.layouts.featured_highlights', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo $__env->make('frontend.layouts.speech', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('frontend.layouts.special_highlight', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('frontend.layouts.managing_board', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="mt-5"></div>
    <div class="mt-5"></div>
    <?php echo $__env->make('frontend.layouts.achivements', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="mt-5"></div>
    <div class="mt-5"></div>
    
    <?php echo $__env->make('frontend.layouts.map_and_contact_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <div class="mt-5"></div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.front_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\palongmodelsc-college\resources\views/frontend/about_us.blade.php ENDPATH**/ ?>