<section class="ftco-intro" style="background-image: url(<?php echo e(asset('frontend')); ?>/images/manner.png);" data-stellar-background-ratio="0.5">
		<div class="overlay"></div>
		<div class="container">
			<div class="row">
				<div class="col-md-8 offset-md-2">
					<h2>শুধুমাত্র লেখাপড়া নয়, বরং আমরা প্রকৃত মানুষ গঠণে বিশ্বাসী</h2>
					<p class="mb-0 text-center">আপনার সন্তানকে প্রকৃত মানুষ হিসেবে গড়ে তুলতে প্রয়োজন একটি সুন্দর শিক্ষার পরিবেশ, একঝাক মেধাবী সহপাঠী, মানবিক ও সুশিক্ষিত শিক্ষকগন, এবং বাস্তবতার আলোকে সুশিক্ষা, আর এই সকল মানদন্ডে আমাদের স্কুল খুবই উপযুক্ত। <br> আপনাকে সন্তানকে মানুষ হিসেবে গড়ে তুলতে আমরা বদ্ধ পরিকর।</p>
				</div>
				
			</div>
		</div>
	</section><?php /**PATH C:\xampp\htdocs\laravel\palongmodelsc-college\resources\views/frontend/layouts/special_highlight.blade.php ENDPATH**/ ?>