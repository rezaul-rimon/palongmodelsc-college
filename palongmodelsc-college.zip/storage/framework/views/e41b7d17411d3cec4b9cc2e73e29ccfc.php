

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="">
            <div class="col-md-6 offset-md-3">
                <h2 class="text-center text-primary my-4">গ্যালারী যুক্ত করুন</h2>
    
                <div class="border p-4 rounded">
                    <form action="<?php echo e(route('backend.store_gallery')); ?>" method="POST" id="notice" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="form-group mb-4">
                            <label for="galleryTitle" class="text-info">গ্যালারী টাইটেল <span class="text-danger">*</span></label>
                            <input type="text" class="form-control <?php $__errorArgs = ['galleryTitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="galleryTitle" name="galleryTitle" value="<?php echo e(old('galleryTitle')); ?>" required placeholder="উদাহরণঃ সবার জন্য কম্পিউটার প্রশিক্ষণ প্রোগ্রাম">
                            <?php $__errorArgs = ['galleryTitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    
                        <div class="form-group mb-4">
                            <label for="galleryPhotos" class="text-info">গ্যালারী ছবি <span class="text-danger">*</span> <span class="text-primary">(একাধিক ছবি সিলেক্ট করা যাবে)</span></label>
                            <input type="file" class="form-control <?php $__errorArgs = ['galleryPhotos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="galleryPhotos" name="galleryPhotos[]" multiple>
                            <?php $__errorArgs = ['galleryPhotos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                        <div class="row">
                            <div class="col-6">
                                <div class="form-group">
                                    <a class="btn btn-warning form-control" href="<?php echo e(route('backend.gallery')); ?>">ফিরে যান</a>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <input type="submit" value="যুক্ত করুন" class="btn btn-success form-control">
                                </div>
                            </div>
                        </div>
    
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

            
<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend.layouts.back_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\palongmodelsc-college\resources\views/backend/gallery/add_gallery.blade.php ENDPATH**/ ?>