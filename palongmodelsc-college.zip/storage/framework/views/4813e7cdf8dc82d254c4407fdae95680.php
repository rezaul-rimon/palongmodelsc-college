

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="">
            <div class="col-md-6 offset-md-3">
                <h2 class="text-center text-primary my-4">নতুন ইভেন্ট যুক্ত করুন</h2>
    
                <div class="border p-4 rounded">
                    <form action="<?php echo e(route('backend.store_event')); ?>" method="POST" id="notice" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="form-group mb-4">
                            <label for="eventName" class="text-info">ইভেন্টের নাম <span class="text-danger">*</span></label>
                            <input type="text" class="form-control <?php $__errorArgs = ['eventName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="eventName" name="eventName" value="<?php echo e(old('eventName')); ?>" required placeholder="উদাহরণঃ বার্ষিক ক্রীয়া ও পুরষ্কার বিতরণী অনুষ্ঠান">
                            <?php $__errorArgs = ['eventName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
    
                        <div class="form-group mb-4">
                            <label for="eventDate" class="text-info">ইভেন্টের তারিখ <span class="text-danger">*</span></label>
                            <input type="date" class="form-control <?php $__errorArgs = ['eventDate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="eventDate" name="eventDate" value="<?php echo e(old('eventDate')); ?>" required>
                            <?php $__errorArgs = ['eventDate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    
                        <div class="form-group mb-4">
                            <label for="eventDescription" class="text-info">ইভেন্টের বিস্তারিত <span class="text-danger">*</span></label>
                            <textarea class="form-control <?php $__errorArgs = ['eventDescription'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="eventDescription" name="eventDescription" required rows="4" placeholder="উদাহরণঃ আগামী ২-ফেব্রুয়ারী ২০২৪ ইং তারিখে পালং আদর্শ স্কুল ও কলেজের বার্ষিক ক্রীয়া ও পুরষ্কার বিতরণী অনুষ্ঠান অনুষ্ঠিত হইবে..."><?php echo e(old('eventDescription')); ?></textarea>
                            <?php $__errorArgs = ['eventDescription'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>                    
                    
                        <div class="form-group mb-4">
                            <label for="eventPhoto" class="text-info">ইভেন্টের ছবি <span class="text-primary">(ঐচ্ছিক)</span></label>
                            <input type="file" class="form-control <?php $__errorArgs = ['eventPhoto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="eventPhoto" name="eventPhoto" value="<?php echo e(old('eventPhoto')); ?>">
                            <?php $__errorArgs = ['eventPhoto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                        <div class="row">
                            <div class="col-6">
                                <div class="form-group">
                                    <a class="btn btn-warning form-control" href="<?php echo e(route('backend.event')); ?>">ফিরে যান</a>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <input type="submit" value="যুক্ত করুন" class="btn btn-success form-control">
                                </div>
                            </div>
                        </div>
    
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

            
<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend.layouts.back_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\palongmodelsc-college\resources\views/backend/events/add_event.blade.php ENDPATH**/ ?>