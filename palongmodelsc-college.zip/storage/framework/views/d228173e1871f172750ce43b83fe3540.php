

<?php $__env->startSection('content'); ?>

	<?php echo $__env->make('frontend.layouts.hero_single_page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <section class="ftco-section contact-section">
        <div class="container">
            <div class="row d-flex contact-info">
                <div class="col-md-3 d-flex">
                    <div class="bg-light align-self-stretch box p-4 text-center">
                        <h3 class="mb-2">আমাদের ঠিকানাঃ</h3>
                        <p>রত্নাপালং, কোটবাজার-৪৭৫০, টেকনাফ হাইওয়ে, উখিয়া, কক্সবাজার</p>
                    </div>
                </div>
                <div class="col-md-3 d-flex">
                    <div class="bg-light align-self-stretch box p-4 text-center">
                        <h3 class="mb-2">যোগাযোগ এর নাম্বার</h3>
                        <p><a href="#">+ 1235 2355 98</a></p>
                    </div>
                </div>
                <div class="col-md-3 d-flex">
                    <div class="bg-light align-self-stretch box p-4 text-center">
                        <h3 class="mb-2">ইমেইলঃ</h3>
                        <p><a href="#"></a></p>
                    </div>
                </div>
                <div class="col-md-3 d-flex">
                    <div class="bg-light align-self-stretch box p-4 text-center">
                        <h3 class="mb-2">হোয়াটস এপ</h3>
                        <p><a href="#">yoursite.com</a></p>
                    </div>
                </div>
            </div>
        </div>
        </section>

        <div class="col-md-6 offset-md-3">
            <?php if(session()->has('success')): ?>
                <div class="alert alert-success text-center">
                    <?php echo e(session('success')); ?>

                </div>
            <?php elseif(session()->has('error')): ?>
                <div class="alert alert-danger text-center">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>
        </div>
        <script>
            $(document).ready(function() {
                $('.alert').delay(15000).fadeOut(500);
            });
        </script> 
    
        <?php echo $__env->make('frontend.layouts.map_and_contact_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <div class="mt-5"></div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.front_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\palongmodelsc-college\resources\views/frontend/contact_us.blade.php ENDPATH**/ ?>