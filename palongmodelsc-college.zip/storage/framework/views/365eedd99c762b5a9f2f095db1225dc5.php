<footer class="ftco-footer ftco-bg-dark ftco-section" style="padding: 20px 10px 5px 10px !important">
    <div class="container">
        <div class="row">
			<?php
				use App\Helpers\AppHelper;
			?>
            <div class="col-md-12 text-center">
                <p style="font-size: 17px;">কপিরাইট &copy; <?php echo e(AppHelper::en2bn(now()->year)); ?> সকল সত্বাধিকারী পালং আদর্শ স্কুল ও কলেজ <br> This website is made with <span style="color: burlywood">Md. Rezaul Islam Khan</span> 
					
				</p>
            </div>
        </div>
    </div>
</footer>


	<!-- loader -->
	

				
	<script src="<?php echo e(asset('frontend/js/jquery.min.js')); ?>"></script>
	<script src="<?php echo e(asset('frontend/js/jquery-migrate-3.0.1.min.js')); ?>"></script>
	<script src="<?php echo e(asset('frontend/header/js/all.min.js')); ?>"></script>
	<script src="<?php echo e(asset('frontend/js/popper.min.js')); ?>"></script>
	<script src="<?php echo e(asset('frontend/js/bootstrap.min.js')); ?>"></script>
	<script src="<?php echo e(asset('frontend/js/jquery.easing.1.3.js')); ?>"></script>
	<script src="<?php echo e(asset('frontend/js/jquery.waypoints.min.js')); ?>"></script>
	<script src="<?php echo e(asset('frontend/js/jquery.stellar.min.js')); ?>"></script>
	<script src="<?php echo e(asset('frontend/js/owl.carousel.min.js')); ?>"></script>
	
	<script src="<?php echo e(asset('frontend/js/jquery.animateNumber.min.js')); ?>"></script>
	<script src="<?php echo e(asset('frontend/js/scrollax.min.js')); ?>"></script>
	<script src="<?php echo e(asset('frontend/js/main.js')); ?>"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\laravel\palongmodelsc-college\resources\views/frontend/layouts/footer.blade.php ENDPATH**/ ?>