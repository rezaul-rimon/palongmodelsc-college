<section class="ftco-section ftco-no-pb">
		<div class="container">
			<div class="row justify-content-center mb-5 pb-2">
				<div class="col-md-8 text-center heading-section ftco-animate">
					<h2 class="mb-4"><span>অনুমোদিত</span> ম্যানেজিং কমিটি</h2>
					<p>৩০ মার্চ ২০২৩ ইং তারিখে উল্লেখিত, <strong>স্মারক নংঃ- চশিবো/বিদ্যা/কক্স(উখিয়া)/৭৩/৭৮/(অশ-১)/২৭৭৯(২);</strong> মোতাবেক, <br>উপর্যুক্ত বিষয়ে নির্দেশক্রমে জানানো যাচ্ছে যে, উক্ত বিদ্যালয়ের দৈনন্দিন প্রশাসনিক কার্যাবলি পরিচালনার জন্য মাধ্যমিক ও উচ্চ মাধ্যমিক শিক্ষাবোর্ড, চট্টগ্রাম এর প্রবিধানমালা ২০০৯ এর প্রবিধান ৭ ও ৮ আনুসারে গঠিত কমিটিকে প্রথম সভার তারিখ হতে ০২ (দুই) বছরের জন্য অনুমোদন দেয়া হলো। <br><strong>-মাধ্যমিক ও উচ্চ মাধ্যমিক শিক্ষাবোর্ড, চট্টগ্রাম</strong></p>
				</div>
			</div>

			<div class="row">
				<table class="table table-striped table-bordered text-center" style="font-size: 20px;">
					<thead >
						<tr>
							<th style="width: 8%">ক্রম</th>
							<th style="width: 10%">সদস্যের ছবি</th>
							<th style="width: 41%">সদস্যের নাম</th>
							<th style="width: 41%">সদস্যের পদবী</th>
						</tr>
					</thead>

					<tbody>
						<?php $__empty_1 = true; $__currentLoopData = $committee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
							<tr>
								<td class="align-middle"><?php echo e($loop->iteration); ?></td>
								<td class="align-middle">
									<?php if($item->committee_photo != null): ?>
										<img src="<?php echo e(asset('storage/Resources/Committee/Photos/' . $item->committee_photo)); ?>" alt="<?php echo e($item->committee_name); ?> Photo" style="max-width: 80px; height: 80px;">
									<?php else: ?>
										<img src="<?php echo e(asset('storage/Resources/Committee/Photos/committee.png')); ?>" alt="<?php echo e($item->committee_name); ?> Photo" style="max-width: 80px; height: 80px;">
									<?php endif; ?>
								</td>
								<td class="align-middle"><?php echo e($item->committee_name); ?></td>
								<td class="align-middle"><?php echo e($item->committee_designation); ?></td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
							
						<?php endif; ?>
					</tbody>

					

					<tfoot>

					</tfoot>
				</table>
			</div>

		</div>
	</section><?php /**PATH C:\xampp\htdocs\laravel\palongmodelsc-college\resources\views/frontend/layouts/managing_board.blade.php ENDPATH**/ ?>