

<?php $__env->startSection('content'); ?>

	<?php echo $__env->make('frontend.layouts.hero_single_page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('frontend.layouts.notice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo $__env->make('frontend.layouts.events', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="mt-5">

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.front_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\palongmodelsc-college\resources\views/frontend/notice_and_events.blade.php ENDPATH**/ ?>