<footer class="py-4 bg-light mt-auto">
    
</footer><?php /**PATH C:\xampp\htdocs\laravel\palongmodelsc-college\resources\views/backend/layouts/footer.blade.php ENDPATH**/ ?>